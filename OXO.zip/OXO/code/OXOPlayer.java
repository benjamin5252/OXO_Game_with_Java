class OXOPlayer
{
    char letter;

    public OXOPlayer(char playingLetter)
    {
        letter = playingLetter;
    }

    public char getPlayingLetter()
    {
        return letter;
    }
}
